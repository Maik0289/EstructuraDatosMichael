
public class recursividadTarea {
    
    public int numInvertido (int numero){
        int[] vector= valores (numero);
            return numInvertidoR (vector, numero, 0, vector.length-1);
        
    }
    
    
    private int 
            
    private int numInvertidoR (int numero, int[] vector, int numNormal,
            int numInvertido, int i ){
        if (i >=0){
            numInvertido += vector [i]* (int) Math.pow(10, 1);
            return numInvertidoR (vector , numNormal , numInvertido , i-1);
             }
        else {
            return numInvertido;
    }
            
  }

            
        
    

 
