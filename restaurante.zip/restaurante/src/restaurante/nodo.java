
package restaurante;


public class nodo {
    private platos valor;
    private nodo siguiente;

    public nodo(platos plato, nodo siguiente1) {
        this.valor = valor;
        this.siguiente = null;
    }

    public platos getValor() {
        return valor;
    }

    public void setValor(platos valor) {
        this.valor = valor;
    }

    public nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(nodo siguiente) {
        this.siguiente = siguiente;
    }

   

    }
    
    
    
    
   

