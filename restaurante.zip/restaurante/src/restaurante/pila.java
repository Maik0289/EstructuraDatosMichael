
package restaurante;

import javax.swing.JOptionPane;





public class pila {
    private nodo cima; 
    private int largo;
     String Lista = "";
     
    
    public pila() {
        this.cima = null;
        this.largo = 0;
    }
    
    public boolean Vacia(){ 
        return cima == null;
    }
    
    public int tamano(){ 
        return this.largo;
    }
    
    
    public void push(platos plato) {
    nodo nuevoNodo = new nodo();
    nuevoNodo.setValor(plato);

    if (cima == null) {
        cima = nuevoNodo;
    } else {
        platos platoSuperior = cima.getValor();

        if ((platoSuperior.getPlatos().equals("Plato") || platoSuperior.getPlatos().equals("Vaso")) &&
                (plato.getPlatos().equals("Vaso") || plato.getPlatos().equals("Plato"))) {
            plato.setCubiertos(plato.getCubiertos() + platoSuperior.getCubiertos());
            cima = new nodo (plato, cima.getSiguiente());
        } else {
            nuevoNodo.setSiguiente(cima);
            cima = nuevoNodo;
        }
    }
}
    
    public platos pop(){
        platos platoAEliminar = null;
        if (!Vacia()) {
            platoAEliminar = this.cima.getValor();
            this.cima = this.cima.getSiguiente();
            this.largo--;
        }
        
        return platoAEliminar;
    }
    
    
    public boolean search(platos reference) {
        nodo aux = cima;
        boolean exist = false;
        while (exist != true && aux != null) {
            if (reference.getId().equals(aux.getValor().getId())) {
            exist = true;
            } else {
            aux = aux.getSiguiente();
            }
        }
        return exist;
    
    }

    
    public void impresion(){
        nodo recorrido = cima;
        
        while(recorrido != null){
            Lista += recorrido.getValor() + "\n";
            recorrido = recorrido.getSiguiente();
        }
        JOptionPane.showMessageDialog(null, Lista);
        Lista = "";
    }
    
    
}
