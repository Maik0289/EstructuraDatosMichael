
package restaurante;


public class platos {

    String platos;
    String vasos;
    String cubiertos;
    String id;

    public platos(String platos, String vasos, String cubiertos, String id) {
        this.platos = platos;
        this.vasos = vasos;
        this.cubiertos = cubiertos;
        this.id = id;
    }

    public String getPlatos() {
        return platos;
    }

    public void setPlatos(String platos) {
        this.platos = platos;
    }

    public String getVasos() {
        return vasos;
    }

    public void setVasos(String vasos) {
        this.vasos = vasos;
    }

    public String getCubiertos() {
        return cubiertos;
    }

    public void setCubiertos(String cubiertos) {
        this.cubiertos = cubiertos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    
    
    
    
    
    

    
}
