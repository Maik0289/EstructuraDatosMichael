
package restaurante;


public class main {
    public static void main(String[] args) {
        
        pila pilaPlatos = new pila();

        platos plato1 = new platos("Plato", "", "3 cubiertos", "1");
        platos plato2 = new platos("Plato", "", "2 cubiertos", "2");
        platos vaso1 = new platos("Vaso", "", "", "3");
        platos plato3 = new platos("Plato", "", "1 cubierto", "4");

        pilaPlatos.push(plato1);
        pilaPlatos.push(plato2);
        pilaPlatos.push(vaso1);
        pilaPlatos.push(plato3);

    
        pilaPlatos.impresion();


        platos platoEliminado = pilaPlatos.pop();
        System.out.println("Plato eliminado: " + platoEliminado);


        platos platoBuscado = new platos("", "", "2 cubiertos", "2");
        boolean existePlato = pilaPlatos.search(platoBuscado);
        if (existePlato) {
            System.out.println("El plato buscado existe en la pila.");
        } else {
            System.out.println("El plato buscado no existe en la pila.");
        }
    }
}
    

